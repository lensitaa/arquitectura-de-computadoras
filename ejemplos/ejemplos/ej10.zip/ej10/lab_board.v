module lab_board(
    input  wire        clk,
    input  wire        reset,
    input  wire [7:0]  addr,
    input  wire        rd,
    input  wire        wr,
    input  wire [7:0]  wdata,
    output reg  [7:0]  rdata,
    output wire        cs0,
    output wire        cs1,
    output wire        cs2,
    output wire        cs3
);

    // Instanciar io_decoder
    io_decoder decoder (
        .addr(addr),
        .rd(rd),
        .wr(wr),
        .cs0(cs0),
        .cs1(cs1),
        .cs2(cs2),
        .cs3(cs3)
    );

    // Dispositivos dummy, registros de 8 bits
    reg [7:0] dev0, dev1, dev2, dev3;

    always @(posedge clk or posedge reset) begin
        if (reset) begin
            dev0 <= 8'd0;
            dev1 <= 8'd0;
            dev2 <= 8'd0;
            dev3 <= 8'd0;
            rdata <= 8'd0;
        end else begin
            // Escritura (wr) en el dispositivo habilitado
            if (wr) begin
                if (cs0) dev0 <= wdata;
                if (cs1) dev1 <= wdata;
                if (cs2) dev2 <= wdata;
                if (cs3) dev3 <= wdata;
            end

            // Lectura (rd) desde el dispositivo habilitado
            if (rd) begin
                if (cs0) rdata <= dev0;
                else if (cs1) rdata <= dev1;
                else if (cs2) rdata <= dev2;
                else if (cs3) rdata <= dev3;
                else rdata <= 8'd0;
            end else begin
                rdata <= 8'd0;
            end
        end
    end

endmodule
