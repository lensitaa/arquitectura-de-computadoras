module io_decoder(
    input  wire [7:0] addr,
    input  wire       rd,
    input  wire       wr,
    output wire       cs0,
    output wire       cs1,
    output wire       cs2,
    output wire       cs3
);

    wire access = rd | wr;

    assign cs0 = access & (addr >= 8'h00) & (addr <= 8'h0F);
    assign cs1 = access & (addr >= 8'h10) & (addr <= 8'h1F);
    assign cs2 = access & (addr >= 8'h20) & (addr <= 8'h2F);
    assign cs3 = access & (addr >= 8'h30) & (addr <= 8'h3F);

endmodule
