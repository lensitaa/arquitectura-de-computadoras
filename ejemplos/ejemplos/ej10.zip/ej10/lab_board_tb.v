`timescale 1ns / 1ps

module tb_lab_board;

    reg clk;
    reg reset;
    reg [7:0] addr;
    reg rd;
    reg wr;
    reg [7:0] wdata;
    wire [7:0] rdata;
    wire cs0, cs1, cs2, cs3;

    // Instanciar lab_board
    lab_board dut (
        .clk(clk),
        .reset(reset),
        .addr(addr),
        .rd(rd),
        .wr(wr),
        .wdata(wdata),
        .rdata(rdata),
        .cs0(cs0),
        .cs1(cs1),
        .cs2(cs2),
        .cs3(cs3)
    );

    // Generador de reloj: 10 ns periodo (100 MHz)
    initial clk = 0;
    always #5 clk = ~clk;

    initial begin
        // Inicialización
        reset = 1;
        addr = 8'd0;
        rd = 0;
        wr = 0;
        wdata = 8'd0;

        #20;
        reset = 0;

        // Escritura en dispositivo 0 (dirección 0x0A)
        @(posedge clk);
        addr = 8'h0A;
        wdata = 8'h55;
        wr = 1;
        rd = 0;
        #10;
        wr = 0;

        // Lectura en dispositivo 0
        @(posedge clk);
        addr = 8'h0A;
        wr = 0;
        rd = 1;
        #10;
        rd = 0;

        // Escritura en dispositivo 1 (dirección 0x15)
        @(posedge clk);
        addr = 8'h15;
        wdata = 8'hAA;
        wr = 1;
        rd = 0;
        #10;
        wr = 0;

        // Lectura en dispositivo 1
        @(posedge clk);
        addr = 8'h15;
        wr = 0;
        rd = 1;
        #10;
        rd = 0;

        // Escritura en dispositivo 2 (dirección 0x2B)
        @(posedge clk);
        addr = 8'h2B;
        wdata = 8'hF0;
        wr = 1;
        rd = 0;
        #10;
        wr = 0;

        // Lectura en dispositivo 2
        @(posedge clk);
        addr = 8'h2B;
        wr = 0;
        rd = 1;
        #10;
        rd = 0;

        // Escritura en dispositivo 3 (dirección 0x3C)
        @(posedge clk);
        addr = 8'h3C;
        wdata = 8'h0F;
        wr = 1;
        rd = 0;
        #10;
        wr = 0;

        // Lectura en dispositivo 3
        @(posedge clk);
        addr = 8'h3C;
        wr = 0;
        rd = 1;
        #10;
        rd = 0;

        // Dirección fuera de rango (0x40), no se activa ningún cs
        @(posedge clk);
        addr = 8'h40;
        wdata = 8'hFF;
        wr = 1;
        rd = 0;
        #10;
        wr = 0;

        @(posedge clk);
        addr = 8'h40;
        rd = 1;
        wr = 0;
        #10;
        rd = 0;

        // Finalizar simulación
        #20;
        $finish;
    end

    // Monitor para ver señales en consola (opcional)
    initial begin
        $dumpfile("tb_lab_board.vcd");
        $dumpvars(0, tb_lab_board);
    end

endmodule
