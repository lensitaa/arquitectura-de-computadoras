module uart (
    input wire clk,         // Reloj del sistema 50MHz
    input wire rst,         // Reset sincrónico activo alto
    input wire rx,          // Entrada RX (recibir datos)
    output reg tx,          // Salida TX (transmitir datos)
    input wire [7:0] tx_data, // Datos a transmitir
    input wire tx_start,    // Inicio transmisión
    output reg tx_busy,     // Transmisión en curso
    output reg [7:0] rx_data, // Datos recibidos
    output reg rx_ready     // Nuevo dato recibido
);

    parameter IDLE = 0, START=1, DATA=2, STOP=3;
    parameter CLKS_PER_BIT = 5208; // 50M / 9600 ~ 5208 reloj ciclos por bit UART

    reg [12:0] clk_count = 0;     // Contador de ciclos reloj
    reg [2:0] bit_index = 0;      // Índice de bit transmitido o recibido
    reg [3:0] state_tx = IDLE;
    reg [3:0] state_rx = IDLE;
    reg [7:0] tx_shift_reg = 0;
    reg [7:0] rx_shift_reg = 0;

    // Transmisión
    always @(posedge clk) begin
        if (rst) begin
            state_tx <= IDLE;
            tx <= 1'b1; // Línea TX idle alta
            tx_busy <= 0;
            clk_count <= 0;
            bit_index <= 0;
        end else begin
            case (state_tx)
                IDLE: begin
                    tx <= 1'b1;
                    tx_busy <= 0;
                    if (tx_start) begin
                        tx_shift_reg <= tx_data;
                        state_tx <= START;
                        tx_busy <= 1;
                        clk_count <= 0;
                    end
                end
                START: begin
                    tx <= 1'b0; // Start bit
                    if (clk_count < CLKS_PER_BIT -1) 
                        clk_count <= clk_count + 1;
                    else begin
                        clk_count <= 0;
                        state_tx <= DATA;
                        bit_index <= 0;
                    end
                end
                DATA: begin
                    tx <= tx_shift_reg[bit_index];
                    if (clk_count < CLKS_PER_BIT -1)
                        clk_count <= clk_count +1;
                    else begin
                        clk_count <= 0;
                        if (bit_index < 7)
                            bit_index <= bit_index +1;
                        else
                            state_tx <= STOP;
                    end
                end
                STOP: begin
                    tx <= 1'b1; // Stop bit
                    if (clk_count < CLKS_PER_BIT -1)
                        clk_count <= clk_count +1;
                    else begin
                        clk_count <= 0;
                        state_tx <= IDLE;
                        tx_busy <= 0;
                    end
                end
            endcase
        end
    end

    // Recepción
    always @(posedge clk) begin
        if (rst) begin
            state_rx <= IDLE;
            clk_count <= 0;
            bit_index <= 0;
            rx_ready <= 0;
            rx_data <= 0;
        end else begin
            case (state_rx)
                IDLE: begin
                    rx_ready <= 0;
                    if (rx == 0) begin // Detectar start bit (bajada)
                        state_rx <= START;
                        clk_count <= CLKS_PER_BIT/2; // Para muestrear centrado en medio bit
                    end
                end
                START: begin
                    if (clk_count > 0)
                        clk_count <= clk_count - 1;
                    else begin
                        state_rx <= DATA;
                        clk_count <= CLKS_PER_BIT -1;
                        bit_index <= 0;
                    end
                end
                DATA: begin
                    if (clk_count > 0)
                        clk_count <= clk_count - 1;
                    else begin
                        rx_shift_reg[bit_index] <= rx;
                        clk_count <= CLKS_PER_BIT -1;
                        if (bit_index < 7)
                            bit_index <= bit_index + 1;
                        else
                            state_rx <= STOP;
                    end
                end
                STOP: begin
                    if (clk_count > 0)
                        clk_count <= clk_count - 1;
                    else begin
                        if (rx == 1) begin // Validar bit de stop
                            rx_data <= rx_shift_reg;
                            rx_ready <= 1;
                        end
                        state_rx <= IDLE;
                    end
                end
            endcase
        end
    end

endmodule
