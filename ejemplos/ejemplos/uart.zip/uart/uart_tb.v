`timescale 1ns / 1ps
`include "uart.v"

module tb_uart;

    reg clk = 0;
    reg rst = 1;
    reg rx = 1; // Línea idle alta (sin datos)
    reg [7:0] tx_data;
    reg tx_start = 0;

    wire tx;
    wire tx_busy;
    wire [7:0] rx_data;
    wire rx_ready;

    // Instancia del módulo UART
    uart uut (
        .clk(clk),
        .rst(rst),
        .rx(rx),
        .tx(tx),
        .tx_data(tx_data),
        .tx_start(tx_start),
        .tx_busy(tx_busy),
        .rx_data(rx_data),
        .rx_ready(rx_ready)
    );

    // Generador de reloj 50MHz
    always #10 clk = ~clk; // período = 20ns

    // Tarea para enviar byte desde UART
    task uart_send_byte(input [7:0] data);
        begin
            @(negedge clk);
            tx_data = data;
            tx_start = 1;
            @(negedge clk);
            tx_start = 0;

            // Esperar a que termine la transmisión
            wait (tx_busy == 0);
            // Tiempo entre bytes
            #104167; // un poco más que 1/9600 baudios
        end
    endtask

    initial begin
      $dumpfile("uart_tb.vcd");
      $dumpvars(0, tb_uart);
        // Inicialización
        rst = 1;
        #50;
        rst = 0;

        // Enviar "H", "i"
        uart_send_byte(8'h48); // 'H'
        uart_send_byte(8'h69); // 'i'

        // Prueba recepción sencilla (echo)
        // Aquí simulas recibir datos colocando bits en la línea rx,
        // o conecta la línea rx a una fuente externa en simulación/FPGA real.

        #500000; // Esperar un tiempo para completar

        $stop;
    end

endmodule
